# disaster-management
Disaster management project  created by aditya collage of engineering [students]
- M durga prasad
- P Tejaswini venkata sai
- Kvv satya ravi
- Achuer ayuel
- G harsha vardhan

# description
A disaster is a serious disruption in the functioning of a community or a society,
which exceed the ability of the affected community or the society to cope using its own
resources; for instance, there is a widespread human, economic, environmental and
material impact due to turbulent cyclones. Disaster Management refers to conservation of
lives and property during a natural and man-made disaster. Disaster management plans are
multi-layered and are planned to address issues such as floods, hurricanes, fires, mass
failure of utilities, rapid spread of disease and droughts. 


With the help of this project we can prevent the damage occurred to some extent.
This project management we have three phases with respect to the stages of disaster is
made with the Moto to help people. We use Django in this project. Django is a highlevel Python web framework that encourages rapid development and clean pragmatic
design.

# Languages
- Python,Html,Css,JAvascript,Django(Web Framework)

# Documentation
[doc.pdf](https://github.com/kvvsatyaravi/disaster-management/blob/master/doc.pdf)

# Requirements 
1) first install python 3.+
2) next install django 

# instructions to run application
1) cd disaster management
2) open command prompt on that folder
3) python manage.py migrate
4) python manage.py runserver
5) go to browser enter 127.0.0.1:8000 in url 

for more information or guidance open doc.pdf


License
----

MIT

